
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let dino = { x: 50, y: 150, width: 40, height: 40, vy: 0, gravity: 1.5, jumping: false };
let obstacle = { x: 800, y: 160, width: 20, height: 40, speed: 6 };
let gameOver = false;

document.addEventListener("keydown", (e) => {
  if (e.code === "Space" && !dino.jumping) {
    dino.vy = -20;
    dino.jumping = true;
  }
});

function update() {
  dino.y += dino.vy;
  dino.vy += dino.gravity;

  if (dino.y >= 150) {
    dino.y = 150;
    dino.vy = 0;
    dino.jumping = false;
  }

  obstacle.x -= obstacle.speed;
  if (obstacle.x + obstacle.width < 0) {
    obstacle.x = 800 + Math.random() * 200;
  }

  if (
    dino.x < obstacle.x + obstacle.width &&
    dino.x + dino.width > obstacle.x &&
    dino.y < obstacle.y + obstacle.height &&
    dino.y + dino.height > obstacle.y
  ) {
    gameOver = true;
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Dino
  ctx.fillStyle = "black";
  ctx.fillRect(dino.x, dino.y, dino.width, dino.height);

  // Obstacle
  ctx.fillStyle = "green";
  ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);

  // Ground line
  ctx.strokeStyle = "#999";
  ctx.beginPath();
  ctx.moveTo(0, 190);
  ctx.lineTo(800, 190);
  ctx.stroke();
}

function loop() {
  if (!gameOver) {
    update();
    draw();
    requestAnimationFrame(loop);
  } else {
    ctx.font = "30px Arial";
    ctx.fillStyle = "red";
    ctx.fillText("Game Over", 300, 100);
  }
}

loop();


# Dino Offline Game (Clone)

Ini adalah clone sederhana dari game Dino Google Chrome saat offline.

## Cara Main
- Buka file `index.html` di browser.
- Tekan **Spasi** untuk melompat dan hindari rintangan.
- Bisa dijalankan langsung di HP atau laptop tanpa internet.

## Akses Online via GitHub Pages (Setelah Upload)
1. Upload semua file ini ke repository GitHub Anda.
2. Aktifkan GitHub Pages di tab **Settings > Pages**.
3. Pilih source: **main branch /root**.
4. Akses game Anda melalui link: `https://username.github.io/nama-repo/`

Ganti `username` dengan nama GitHub Anda dan `nama-repo` dengan nama repository-nya.
